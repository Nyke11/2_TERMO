const nome = "Carlos"; let idade = 16;
const curso = "Desenvolvimento de Sistemas"; const matriculado = true;
console.log(nome); console.log(idade); console.log(curso); console.log(matriculado);
console.log("Nome:", nome); console.log("Idade:", idade); console.log("Curso:", curso);
console.log("Está matriculado?", matriculado);
