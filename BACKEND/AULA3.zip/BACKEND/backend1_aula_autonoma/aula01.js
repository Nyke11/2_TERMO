console.log("Olá, Mundo!");
console.log("Estou começando a aprender JavaScript.");
console.log("Esta é a disciplina de Backend 1.");